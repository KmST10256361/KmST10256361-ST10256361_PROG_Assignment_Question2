/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog_question_2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author karan
 */
public class Points_and_FoulsTest {
    
    public Points_and_FoulsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of input method, of class Points_and_Fouls.
     */
    @Test
    public void testInput() {
        System.out.println("input");
        Points_and_Fouls instance = new Points_and_Fouls();
       
        // TODO review the generated test code and remove the default call to fail.
     
    }

    /**
     * Test of Display method, of class Points_and_Fouls.
     */
    @Test
    public void testDisplay() {
        System.out.println("Display");
        Points_and_Fouls instance = new Points_and_Fouls();
        instance.Display();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of ReportNameDisplay method, of class Points_and_Fouls.
     */
    @Test
    public void testReportNameDisplay() {
        System.out.println("ReportNameDisplay");
        Points_and_Fouls instance = new Points_and_Fouls();
        instance.ReportNameDisplay();
        // TODO review the generated test code and remove the default call to fail.

    }
    
}
